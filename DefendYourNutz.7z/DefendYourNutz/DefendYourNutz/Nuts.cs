﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
//using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;
using Microsoft.Xna.Framework.Content;
using MonoGameLibrary.Sprite2;
using MonoGameLibrary.Util;

namespace DefendYourNutz
{
    class Nuts : DrawableSprite2
    {
        public Nuts(Game game)
            : base(game)
        {

        }


        protected override void LoadContent()
        {
            this.spriteTexture = this.Game.Content.Load<Texture2D>("nuts");
            this.Location = new Vector2(0, 0); //HACK hard coded location
            base.LoadContent();
        }
    }
}

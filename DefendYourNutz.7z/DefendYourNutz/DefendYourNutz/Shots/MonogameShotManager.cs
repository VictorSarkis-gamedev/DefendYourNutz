﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
//using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;
using Microsoft.Xna.Framework.Content;
using MonoGameLibrary.Sprite2;
using MonoGameLibrary.Util;


namespace DefendYourNutz
{
    class MonogameShotManager : ShotManager


    {
        List<Shot> ShotsToRemove;

        public MonogameShotManager(Game1 game)
            : base(game)
        {
            ShotsToRemove = new List<Shot>();
        }

        public override void Update(GameTime gameTime)
        {
            foreach (Shot s in Shots)
            {
                if (s.Location.X > this.Game.GraphicsDevice.Viewport.Width)
                {
                    ShotsToRemove.Add(s);
                }

                if (s.Location.X < 0)
                {
                    ShotsToRemove.Add(s);
                }

                if (s.Location.Y > this.Game.GraphicsDevice.Viewport.Height)
                {
                    ShotsToRemove.Add(s);
                }

                if (s.Location.Y < 0)
                {
                    ShotsToRemove.Add(s);
                }
            }

            foreach (Shot str in ShotsToRemove)
            {
                this.Shots.Remove(str);
            }
            ShotsToRemove.Clear();

            base.Update(gameTime);

        }
    }
}

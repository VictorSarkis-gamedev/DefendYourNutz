﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
//using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;
using Microsoft.Xna.Framework.Content;
using MonoGameLibrary.Sprite2;

namespace DefendYourNutz
{
    class ScoreManager : DrawableGameComponent
    {

        SpriteFont font;
        public static int Nuts;
        public static int Score;

        SpriteBatch sb;
        Vector2 nutsLoc, scoreLoc;

        public ScoreManager(Game game)
            : base(game)
        {
            SetupNewGame();
        }

        private static void SetupNewGame()
        {
            Nuts = 5;
            Score = 0;
        }

        protected override void LoadContent()
        {
            sb = new SpriteBatch(this.Game.GraphicsDevice);
            font = this.Game.Content.Load<SpriteFont>("Arial");
            nutsLoc = new Vector2(100, 10);
            scoreLoc = new Vector2(400, 10);
            base.LoadContent();
        }

        public override void Draw(GameTime gameTime)
        {
            sb.Begin();
            sb.DrawString(font, "Nuts: " + Nuts, nutsLoc, Color.White);
            sb.DrawString(font, "Score: " + Score, scoreLoc, Color.White);
            sb.End();
            base.Draw(gameTime);
        }

        internal static void GameOver()
        {
            throw new NotImplementedException();
        }

    }
}

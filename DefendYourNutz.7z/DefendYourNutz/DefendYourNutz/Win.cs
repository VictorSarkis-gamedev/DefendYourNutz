﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
//using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;
using Microsoft.Xna.Framework.Content;
using MonoGameLibrary.Sprite2;

namespace DefendYourNutz
{
    class Win : DrawableGameComponent
    {
        SpriteFont font;

        SpriteBatch sb;
        Vector2 winLoc;

        RandomLocationPossumSpawner rps;
        RandomLocationPlusNutSpawner rpns;
        Squirrel s;

        public Win(Game game, RandomLocationPossumSpawner rps, RandomLocationPlusNutSpawner rpns, Squirrel s)
            : base(game)
        {
            this.s = s;
            this.rps = rps;
            this.rpns = rpns;
        }

        public override void Update(GameTime gameTime)
        {
            base.Update(gameTime);
        }

        protected override void LoadContent()
        {
            sb = new SpriteBatch(this.Game.GraphicsDevice);
            font = this.Game.Content.Load<SpriteFont>("Arial");
            winLoc = new Vector2(250,200);
            base.LoadContent();
        }

        public override void Draw(GameTime gameTime)
        {
            sb.Begin();
            if (ScoreManager.Nuts >= 10)
            {
                s.Speed = 0;
                rps.Enabled = false;
                rpns.Enabled = false;
                sb.DrawString(font, "YOU HAVE ENOUGH ENOUGH NUTS TO SURVIVE THE WINTER! YOU WIN!", winLoc, Color.RoyalBlue);
            }
            sb.End();
            base.Draw(gameTime);
        }
    }
}
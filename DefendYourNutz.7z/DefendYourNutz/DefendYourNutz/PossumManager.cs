﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
//using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;
using Microsoft.Xna.Framework.Content;
using MonoGameLibrary.Sprite2;
using MonoGameLibrary.Util;

namespace DefendYourNutz
{
    class PossumManager : DrawableGameComponent
    {

        List<Possum> possums;
        InputHandler input;

        public PossumManager(Game game)
            :base (game)
        {
            this.possums = new List<Possum>();

            input = (InputHandler)this.Game.Services.GetService<IInputHandler>();
            if (input == null)
            {
                input = new InputHandler(this.Game);
            }
        }

        public override void Update(GameTime gameTime)
        {

            foreach (var possum in possums)
            {
                //check possums
            }

            if (input.KeyboardState.HasReleasedKey(Keys.G))
            {
                Possum p = new Possum(this.Game);
                p.Initialize();
                
                p.Location = p.GetRandLocation();
                this.AddPossum(p);
            }
            base.Update(gameTime);
        }

        public Possum AddPossum()
        {
            Possum p = new Possum(this.Game);
            p.Initialize();
            return this.AddPossum(p);
        }

        public Possum AddPossum(Possum p)
        {
            this.possums.Add(p);
            this.Game.Components.Add(p);
            return p;
        }
    }
}

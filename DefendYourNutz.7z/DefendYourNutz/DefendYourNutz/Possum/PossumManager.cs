﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
//using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;
using Microsoft.Xna.Framework.Content;
using MonoGameLibrary.Sprite2;
using MonoGameLibrary.Util;

namespace DefendYourNutz
{
    class PossumManager : DrawableGameComponent
    {
        //List<Shot> shots;     //Now from MonogameShotM
        MonogameShotManager mgsm;
        List<Shot> shotToRemove;
        //Shot shots;
        //Squirrel squirrel;
        List<Possum> possums;
        List<Possum> possumsToRemove;
        Random r;

        public PossumManager(Game game, MonogameShotManager mgsm)
            : base(game)
        {
            //this.shots = shots; 
            this.shotToRemove = new List<Shot>();
            this.mgsm = mgsm;
            this.possumsToRemove = new List<Possum>();
            possums = new List<Possum>();
            r = new Random();

        }

        public override void Update(GameTime gameTime)
        {
            possumsToRemove.Clear();
            shotToRemove.Clear();

            //add shot collision and adding to score

            foreach (Possum p in this.possums)
            {
                if (p.Enabled)
                {
                    p.Update(gameTime);
                    foreach (Shot s in this.mgsm.Shots)
                    {
                        if (p.Intersects(s))
                        {
                            p.Visible = false;
                            p.Enabled = false;
                            s.Visible = false;
                            s.Enabled = false;
                            possumsToRemove.Add(p);
                            shotToRemove.Add(s);
                            ScoreManager.Score += 100;
                        }
                    }
                }
            }


            //remove possums left of screen and lose nuts
            foreach (Possum p in this.possums)
            {
                if (p.Location.X < 0)
                {

                    this.LoseNut(gameTime);
                    possumsToRemove.Add(p);
                    //p.Visible = false;
                    //p.Enabled = false;
                }

            }

            //foreach (Possum p in this.possums)
            //{
            //    if (p.Location.X + p.spriteTexture.Width > this.Game.GraphicsDevice.Viewport.Width)
            //    {

            //        this.LoseNut(gameTime);
            //    }
            //}
            foreach (Possum p in this.possumsToRemove)
            {
                this.possums.Remove(p);
                p.Visible = false;
                p.Enabled = false;
            }

            //SHOTSTOREMOVE

            foreach (Shot s in this.shotToRemove)
            {
                this.mgsm.Shots.Remove(s);
                s.Visible = false;
                s.Enabled = false;
            }


            base.Update(gameTime);
        }

        public void LoseNut(GameTime gameTime)
        {
            ScoreManager.Nuts--;
            if (ScoreManager.Nuts == 0)
            {

                // lose condition
                //throw new Exception("All Your Nutz Have Been Taken!");
            }
        }

        public Possum AddPossum()
        {
            Possum p = new Possum(this.Game);
            p.Initialize();
            return AddPossum(p);
        }

        public Possum AddPossum(Possum p)
        {
            this.possums.Add(p);
            this.Game.Components.Add(p);
            return p;
        }


        //SHOTSTOADD

        public Shot AddShot()
        {
            Shot s = new Shot(this.Game);
            s.Initialize();
            return AddShot(s);
        }

        public Shot AddShot(Shot s)
        {
            this.mgsm.Shots.Add(s);
            this.Game.Components.Add(s);
            return s;
        }


    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using Microsoft.Xna.Framework.Storage;
using MonoGameLibrary.Util;

namespace DefendYourNutz
{
    class TimedPossumSpawner : PossumSpawner
    {
        float spawnTime, lastSpawn;

        public void SetSpawnTime(float timeTillNextSpawn)
        {
            this.spawnTime = timeTillNextSpawn;
        }

        public TimedPossumSpawner(Game game, MonogameShotManager mgsm)
            : base(game, mgsm)
        {
            spawnTime = 3000;
            lastSpawn = 0;
        }

        public override void Update(GameTime gameTime)
        {
            if (lastSpawn > spawnTime)
            {
                this.SpawnPossum();
                lastSpawn = 0;
            }

            lastSpawn += gameTime.ElapsedGameTime.Milliseconds;
            base.Update(gameTime);
        }
    }

  
}

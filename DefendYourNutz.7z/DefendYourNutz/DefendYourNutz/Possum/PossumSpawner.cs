﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using Microsoft.Xna.Framework.Storage;
using MonoGameLibrary.Util;

namespace DefendYourNutz
{
    class PossumSpawner : PossumManager
    {
        InputHandler input;

        public PossumSpawner(Game game, MonogameShotManager mgsm) //HACK add shots
            :base(game, mgsm)
        {
            input = (InputHandler)this.Game.Services.GetService<IInputHandler>();
            if (input == null)
            {
                input = new InputHandler(this.Game);
                this.Game.Components.Add(input);
            }
        }

        public override void Update(GameTime gameTime)
        {

            base.Update(gameTime);
        }

        public virtual Possum SpawnPossum()
        {
            Possum p = new Possum(this.Game);
            p.Initialize();
            this.AddPossum(p);
            return p;
        }
    }
}

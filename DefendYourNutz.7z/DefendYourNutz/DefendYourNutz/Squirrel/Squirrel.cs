﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
//using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;
using Microsoft.Xna.Framework.Content;
using MonoGameLibrary.Sprite2;
using MonoGameLibrary.Util;

namespace DefendYourNutz
{
    class Squirrel : DrawableSprite2
    {

        //GameConsole console;
        SquirrelController controller;

        protected MonogameShotManager mgsm;

        public Squirrel(Game game, MonogameShotManager shotmanager)
            :base(game)
        {
            this.Speed = 200;
            controller = new SquirrelController(game);
            this.mgsm = shotmanager;
            /*console = (GameConsole)this.Game.Services.GetService(typeof(IGameConsole));
            if (console == null)
            {
                console = new GameConsole(this.Game);
                this.Game.Components.Add(console); 
            }*/

        }

        protected override void LoadContent()
        {
            this.spriteTexture = this.Game.Content.Load<Texture2D>("squirrel");
            this.Location = new Vector2(40, 20); //HACK hard coded location
            base.LoadContent();
        }

        public override void Update(GameTime gameTime)
        {
            controller.HandleInput(gameTime);
            this.Direction = controller.Direction;

            this.Location += this.Direction * (this.Speed * gameTime.ElapsedGameTime.Milliseconds / 1000);
            KeepSquirrelOnScreen();

            if (this.controller.Shoot)
            {
                mgsm.AddLocationDirectionShot(this.Location, new Vector2(1,0));
            }

            base.Update(gameTime);
        }

        private void KeepSquirrelOnScreen()
        {
            this.Location.Y = MathHelper.Clamp(0, this.Location.Y, this.Game.GraphicsDevice.Viewport.Height - this.spriteTexture.Height);

            if (this.Location.Y > Game.GraphicsDevice.Viewport.Height - (this.spriteTexture.Height ))
                this.Location.Y = Game.GraphicsDevice.Viewport.Height - (this.spriteTexture.Height );

           

        
        }
    }
}

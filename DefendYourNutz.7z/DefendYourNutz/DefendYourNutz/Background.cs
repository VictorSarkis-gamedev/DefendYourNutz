﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
//using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;
using Microsoft.Xna.Framework.Content;
using MonoGameLibrary.Sprite2;
using MonoGameLibrary.Util;

namespace DefendYourNutz
{
    class Background : DrawableSprite2
    {

        SpriteBatch sb;

        public Background(Game game)
            : base(game)
        {

        }


        protected override void LoadContent()
        {
            sb = new SpriteBatch(this.Game.GraphicsDevice);
            this.spriteTexture = this.Game.Content.Load<Texture2D>("ground");
            this.Location = new Vector2(0, 0); //HACK hard coded location
            base.LoadContent();
        }

        public override void Draw(GameTime gameTime)
        {
            sb.Begin();
            sb.End();
            base.Draw(gameTime);
        }
    }
}

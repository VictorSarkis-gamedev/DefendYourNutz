﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
//using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;
using Microsoft.Xna.Framework.Content;
using MonoGameLibrary.Sprite2;
using MonoGameLibrary.Util;

namespace DefendYourNutz
{
    class PlusNutManager : DrawableGameComponent
    {

        //List<Shot> shots;
        MonogameShotManager mgsm;
        List<Shot> shotToRemove;
        //Shot shots;
        //Squirrel squirrel;
        List<PlusNut> plusNuts;
        List<PlusNut> plusNutsToRemove;
        Random rPlusNut;

        public PlusNutManager(Game game, MonogameShotManager mgsm) //HACK add (Shots shots)
            : base(game)
        {
            //this.shots = shots;
            this.shotToRemove = new List<Shot>();
            this.mgsm = mgsm;
            this.plusNutsToRemove = new List<PlusNut>();
            plusNuts = new List<PlusNut>();
            rPlusNut = new Random();

        }

        public override void Update(GameTime gameTime)
        {
            plusNutsToRemove.Clear();
            shotToRemove.Clear();


            //remove possums left of screen and lose nuts
            foreach (PlusNut pn in this.plusNuts)
            {
                if (pn.Enabled)
                { 
                    pn.Update(gameTime);
                    foreach (Shot s in this.mgsm.Shots)
                    {
                        if (pn.Intersects(s))
                        {
                            pn.Visible = false;
                            pn.Enabled = false;
                            s.Visible = false;
                            s.Enabled = false;
                            this.GainNut(gameTime);
                            plusNutsToRemove.Add(pn);
                            shotToRemove.Add(s);
                            ScoreManager.Score +=500;
                        }
                    }
                }
            }

            foreach (PlusNut pn in this.plusNuts)
            {
                if (pn.Location.X < 0)
                {


                    plusNutsToRemove.Add(pn);
                    //p.Visible = false;
                    //p.Enabled = false;
                }
            }

            foreach (PlusNut pn in this.plusNutsToRemove)
            {
                this.plusNuts.Remove(pn);
                pn.Visible = false;
                pn.Enabled = false;
            }

            //SHOTSTOREMOVE

            foreach (Shot s in this.shotToRemove)
            {
                this.mgsm.Shots.Remove(s);
                s.Visible = false;
                s.Enabled = false;
            }

            base.Update(gameTime);
        }

        public void GainNut(GameTime gameTime)
        {
            ScoreManager.Nuts++;

            if (ScoreManager.Nuts == 10)
            {
                // win condition
                //throw new Exception("You Have Enough Nutz For The Winter!");
            }
        }

        public PlusNut AddPlusNut()
        {
            PlusNut pn = new PlusNut(this.Game);
            pn.Initialize();
            return AddPlusNut(pn);
        }

        public PlusNut AddPlusNut(PlusNut pn)
        {
            this.plusNuts.Add(pn);
            this.Game.Components.Add(pn);
            return pn;
        }

        //SHOTSTOADD

        public Shot AddShot()
        {
            Shot s = new Shot(this.Game);
            s.Initialize();
            return AddShot(s);
        }

        public Shot AddShot(Shot s)
        {
            this.mgsm.Shots.Add(s);
            this.Game.Components.Add(s);
            return s;
        }
    }
}

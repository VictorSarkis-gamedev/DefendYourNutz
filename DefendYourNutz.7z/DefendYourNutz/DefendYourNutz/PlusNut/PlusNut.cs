﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
//using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;
using Microsoft.Xna.Framework.Content;
using MonoGameLibrary.Sprite2;
using MonoGameLibrary.Util;

namespace DefendYourNutz
{
    class PlusNut : DrawableSprite2
    {

        Random rPlusNut;

        public PlusNut(Game game)
            : base(game)
        {
            rPlusNut = new Random();
        }

        protected override void LoadContent()
        {
            this.spriteTexture = this.Game.Content.Load<Texture2D>("singlenut");
            //this.Location = new Vector2(200, 100);
            this.Direction = new Vector2(-1, 0);
            this.Speed = 350.0f;
            base.LoadContent();
        }

        public override void Update(GameTime gameTime)
        {
            this.Location += this.Direction * (this.Speed * gameTime.ElapsedGameTime.Milliseconds / 1000);


            base.Update(gameTime);
        }

        public Vector2 GetRandLocation()
        {

            Vector2 loc;
            loc.X = Game.Window.ClientBounds.Width;
            loc.Y = rPlusNut.Next(100, Game.Window.ClientBounds.Height - 62);
            return loc;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
//using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;
using Microsoft.Xna.Framework.Content;
using MonoGameLibrary.Sprite2;
using MonoGameLibrary.Util;

namespace DefendYourNutz
{
    class NutManager : GameComponent
    {
        public List<Nuts> Nuts { get; private set; }

        public NutManager(Game game)
            :base(game)
        {
            this.Nuts = new List<Nuts>();
        }

        public override void Initialize()
        {
            LoadLevel();

            base.Initialize();
        }

        protected virtual void LoadLevel()
        {
            CreateBlockArrayByWidthAndHeight(1, 20, 1);
        }

        private void CreateBlockArrayByWidthAndHeight(int width, int height, int margin)
        {
            Nuts n;
            for (int w = 0; w < width; w++)
            {
                for (int h = 0; h < height; h++)
                {
                    n = new Nuts(this.Game);
                    n.Initialize();
                    n.Location = new Vector2(5 + (w * n.SpriteTexture.Width + (w * margin)), (h * n.SpriteTexture.Height + (h * margin)));
                    Nuts.Add(n);
                    this.Game.Components.Add(n);
                }
            }
        }
    }
}

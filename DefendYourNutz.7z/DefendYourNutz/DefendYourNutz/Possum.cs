﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
//using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Storage;
using Microsoft.Xna.Framework.Content;
using MonoGameLibrary.Sprite2;
using MonoGameLibrary.Util;

namespace DefendYourNutz
{
    class Possum : DrawableSprite2
    {
        public Texture2D possum;
        public Vector2 StartLoc;

        Random r;

        public Possum(Game game)
            :base(game)
        {
            r = new Random();
        }

        protected override void LoadContent()
        {
            this.spriteTexture = this.Game.Content.Load<Texture2D>("possum");
            this.Location = new Vector2(200, 100);
            this.Direction = new Vector2(-1, 0);
            this.Speed = 100.0f;
            base.LoadContent();
        }

        public Vector2 GetRandLocation()
        {
            System.Threading.Thread.Sleep(1);
            Vector2 loc;
            loc.X = r.Next(Game.Window.ClientBounds.Width - + this.spriteTexture.Width);
            loc.Y = r.Next(Game.Window.ClientBounds.Height - this.spriteTexture.Height) + this.spriteTexture.Height;
            return loc;
        }
    }
}
